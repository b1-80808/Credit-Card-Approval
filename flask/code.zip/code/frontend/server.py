from flask import Flask, request, render_template
import pickle

# load the model
with open('../../models/nb.pkl', 'rb') as file:
    model = pickle.load(file)


# create a flask application
app = Flask(__name__)


@app.route("/", methods=["GET"])
def root():
    # read the file contents and send them to client
    return render_template('index.html')


@app.route("/classify", methods=["POST"])
def classify():
    # get the values entered by user
    print(request.form)
    gender = int(request.form.get("gender"))
    own_car = int(request.form.get("own_car"))
    own_reality = int(request.form.get("own_reality"))
    cnt_children = int(request.form.get("cnt_children"))
    income = float(request.form.get("income"))
    education_type = int(request.form.get("education_type"))
    family_status = int(request.form.get("family_status"))
    housing_type = int(request.form.get("housing_type"))
    days_birth = float(request.form.get("days_birth")) * -1
    personal_phone = float(request.form.get("personal_phone"))
    days_employeed = float(request.form.get("days_employeed")) * -1
    work_phone = float(request.form.get("work_phone"))
    email = float(request.form.get("email"))
    begin_months = float(request.form.get("begin_months")) * -1
    status = int(request.form.get("status"))
    # job = float(request.form.get("job"))


    answers = model.predict([
        [gender, own_car, own_reality, cnt_children, income, education_type, family_status, housing_type, days_birth, days_employeed, work_phone, personal_phone, email, 285, begin_months, status]
    ])

    if int(answers[0]) == 1:
        return f"Credit Card Approve"
    else:
        return "Not Approve"



# start the application
app.run(host="0.0.0.0", port=8000, debug=True)
